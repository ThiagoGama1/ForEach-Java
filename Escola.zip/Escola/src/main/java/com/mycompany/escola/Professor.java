/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escola;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author alunolab08
 */
public class Professor {
    private String nome;
    private List<Aluno> lista;
    
    public Professor(String nome){
        this.nome = nome;
        lista = new ArrayList<>();
    }
    
    
    
    public void adicionarAluno(Aluno aluno){
        boolean adicionar = true;
        for(Aluno a : lista){
            if(a.getNome().equals(aluno.getNome())){
            System.out.println("O aluno" + aluno.getNome() +  "ja esta na lista!" );
            adicionar = false;
            break;
        }
        }
        if(adicionar){
            lista.add(aluno);
            aluno.setProfessor(this);
        }
        
       
    }

    public List<Aluno> getLista() {
        return lista;
    }
    
}
