/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escola;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author Thiago
 */
public class Curso {
    private String nome;
    private List<Estudante> listaEstudantes;
    
    public Curso(String nome){
        this.nome = nome;
        listaEstudantes = new ArrayList<>();
    }
    
    public void adicionarEstudante(Estudante a){
        boolean adicionar = true;
        for(Estudante estudante : listaEstudantes){
            if(estudante.getNome().equals(a.getNome())){
                System.out.println("O estudante " + a.getNome()+ "já está matriculado!" );
                adicionar = false;
            }
        }
           if(adicionar){
               listaEstudantes.add(a);
           }
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Estudante> getListaEstudantes() {
        return listaEstudantes;
    }

    public void setListaEstudantes(List<Estudante> listaEstudantes) {
        this.listaEstudantes = listaEstudantes;
    }
    
}
