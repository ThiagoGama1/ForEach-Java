/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.escola;

public class Escola {
    public static void main(String[] args) {
      
        Curso matematica = new Curso("Matemática");
        Curso historia = new Curso("História");

       
        Estudante thiago = new Estudante("Thiago");
        Estudante ana = new Estudante("Ana");

        
        thiago.inscreverEmCurso(matematica);
        ana.inscreverEmCurso(matematica);
        ana.inscreverEmCurso(historia);
        thiago.inscreverEmCurso(matematica);
        
        System.out.println("\nCursos do estudante Thiago:");
        for (Curso curso : thiago.getCursos()) {
            System.out.println("- " + curso.getNome());
        }
        System.out.println("\nEstudantes no curso de Matemática:");
        for (Estudante estudante : matematica.getListaEstudantes()) {
            System.out.println("- " + estudante.getNome());
        }
    }
}

