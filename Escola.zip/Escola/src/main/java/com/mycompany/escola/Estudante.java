/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.escola;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author Thiago
 */
public class Estudante {
    private String nome;
    private List <Curso> cursos;
    public Estudante(String nome) {
        this.nome = nome;
        cursos = new ArrayList<>();
    }
    
    public void inscreverEmCurso(Curso curso){
        boolean adicionarCurso= true;
        for(Curso a: cursos){
            if(a.getNome().equals(curso.getNome())){
                adicionarCurso = false;
                System.out.println("O aluno já está inscrito nesse curso! ");
                break;
            }
        }
            if(adicionarCurso){
                cursos.add(curso);
                System.out.println("Curso adicionado! ");
                curso.adicionarEstudante(this);
            }
        
        
    
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    public void setCursos(List<Curso> cursos) {
        this.cursos = cursos;
    }
    
    
}
