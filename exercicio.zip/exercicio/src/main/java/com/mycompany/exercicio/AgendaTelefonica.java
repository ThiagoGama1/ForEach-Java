/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author alunolab08
 */
public class AgendaTelefonica {
    Map<String, String> colecao = new HashMap<>();
    
    public void Inserir(String nome, String numero){
        colecao.put(nome, numero);
    }
    
    public String buscarNumero(String nome){
        String pegarNumero = colecao.get(nome);
        return pegarNumero;
    }
    
    public void remover(String nome){
        colecao.remove(nome);
    }
    
    public int tamanho(){
        return colecao.size();
    }
    
    public void imprimir(){
        for (String nome : colecao.keySet()) {
        String numero = colecao.get(nome);
        System.out.println("Nome: " + nome + ", Número: " + numero);

        
        
}

        
            
}

}
    
    

