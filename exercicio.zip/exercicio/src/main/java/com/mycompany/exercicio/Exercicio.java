/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio;

/**
 *
 * @author alunolab08
 */
public class Exercicio {

    public static void main(String[] args) {
        AgendaTelefonica a1 = new AgendaTelefonica();
        AgendaTelefonica a2 = new AgendaTelefonica();
        a1.Inserir("Fassina", "11");
        a1.Inserir("Thiago", "22");
        System.out.println(a1.buscarNumero("Thiago"));
        a1.imprimir();
    }
}
