/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lojadeeletronicos;
import java.util.*;
/**
 *
 * @author alunolab08
 */
public class Loja {
    private String nome;
    private String endereco;
    private List <Produto> estoque;
    private Set <String> categoria;
    
    
    public Loja(String nome, String endereco){
        this.nome = nome;
        this.endereco = endereco;
        estoque = new ArrayList<>();
        categoria = new HashSet<>();
    }
 
    public void adicionarProduto(Produto a){
        
        
        for(Produto b : estoque){
            if(b.getId() ==(a.getId())){
                System.out.println("O produto já está no estoque! ");
                return;
            }
        }
       
            estoque.add(a);
            categoria.add(a.getMarca());
        
    }
    public Produto buscarProduto(int id){
        
        for(Produto b : estoque){
            if(b.getId() == id){
                return b;
            }
           
        }
        System.out.println("Produto nao encontrado! ");
        return null;
    }
    
    public void exibirProdutos(String categorias){
        boolean encontrou = false;
        
        for(Produto b : estoque){
            if(b.getMarca().equals(categorias)){
                System.out.println("Categoria: " + categorias);
                System.out.println(b);
                encontrou = true;
            }
        }
        if(!encontrou){
            System.out.println("Nenhum produto encontrado nessa categoria! ");
        }
    }
    
    public void listarCategorias(){
        for(String a : categoria){
            System.out.println(a);
        }
    }
    
}
