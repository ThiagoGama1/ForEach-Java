/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaempresa;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author Thiago
 */
public class Empresa {
    private String nome;
    private String cnpj;
    private List<Funcionario> funcionarios;
    
    public Empresa(String nome, String cnpj){
        this.nome = nome;
        this.cnpj = cnpj;
        funcionarios = new ArrayList<>();
    }
    public void adicionarFuncionario(Funcionario f){
        boolean adicionar = true;
        for(Funcionario a : funcionarios){
            if(a.getNome().equals(f.getNome())){
                System.out.println("O funcionario " + f.getNome() + "já está cadastrado! ");
                adicionar = false;
                break;
            }
     
        }
        if(adicionar){
            funcionarios.add(f);
            f.setEmpresa(this);
            System.out.println("Funcionário adicionado com sucesso! ");
        }
        
    }
    
    public void listarFuncionarios(){
        for(Funcionario a: funcionarios){
            System.out.println(a);
        }
    }
}
